param(
    [string]$BasePath = "d:\unzipper",
    [string]$InboundPath = "d:\unzipper\inbound",
    [string]$ExtractedPath = "d:\unzipper\extracted",
    [int]$CheckIntervalSeconds = 10,
    [int]$EmptyCyclesBeforeRestart = 10
)

$7zipPath = "C:\Program Files\7-Zip\7z.exe"
$LogFolder = Join-Path -Path $BasePath -ChildPath "logs"
$MissingPartsFile = Join-Path -Path $LogFolder -ChildPath "missing_parts_log.txt"
$FailedArchivesFile = Join-Path -Path $LogFolder -ChildPath "failed_archives_log.txt"
$ErrorDetailsFile = Join-Path -Path $LogFolder -ChildPath "error_details_log.txt"
$ErrorCount = 0
$SuccessCount = 0
$ProcessedArchives = @{}
$script:ConsecutiveEmptyCycles = 0

if (-not (Test-Path $LogFolder)) {
    New-Item -ItemType Directory -Path $LogFolder -Force | Out-Null
}

$LogFile = Join-Path -Path $LogFolder -ChildPath "extraction_log_$(Get-Date -Format 'yyyyMMdd_HHmmss').txt"

if (-not (Test-Path $7zipPath)) {
    Write-Host "ERROR: 7-Zip not found at $7zipPath" -ForegroundColor Red
    exit 1
}

$host.UI.RawUI.BackgroundColor = "Black"
Clear-Host

function Write-Log {
    param([string]$Message, [ValidateSet("Info", "Success", "Warning", "Error")][string]$Type = "Info")
    
    $Timestamp = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
    $LogEntry = "[$Timestamp] [$Type] $Message"
    
    try {
        Add-Content -Path $LogFile -Value $LogEntry -Encoding UTF8 -ErrorAction Stop
    } catch { }
    
    $Color = switch ($Type) {
        "Success" { "Green" }
        "Warning" { "Yellow" }
        "Error" { "Red" }
        default { "Cyan" }
    }
    
    Write-Host $LogEntry -ForegroundColor $Color
}

function Write-MissingPartsLog {
    param([string]$ArchiveName, [string]$Message)
    
    $Timestamp = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
    $LogEntry = "[$Timestamp] $ArchiveName : $Message"
    
    try {
        Add-Content -Path $MissingPartsFile -Value $LogEntry -Encoding UTF8 -ErrorAction Stop
    } catch { }
}

function Write-FailedArchiveLog {
    param([string]$ArchiveName, [string]$Reason, [string]$Details)
    
    $Timestamp = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
    $LogEntry = "[$Timestamp] ARCHIVE: $ArchiveName | REASON: $Reason"
    
    try {
        Add-Content -Path $FailedArchivesFile -Value $LogEntry -Encoding UTF8 -ErrorAction Stop
        if ($Details) {
            Add-Content -Path $FailedArchivesFile -Value "    DETAILS: $Details" -Encoding UTF8 -ErrorAction Stop
        }
        Add-Content -Path $FailedArchivesFile -Value "" -Encoding UTF8 -ErrorAction Stop
    } catch { }
}

function Write-ErrorDetailsLog {
    param([string]$Component, [string]$ArchiveName, [string]$Error, [string]$Details)
    
    $Timestamp = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
    $LogEntry = "[$Timestamp] COMPONENT: $Component | ARCHIVE: $ArchiveName | ERROR: $Error | DETAILS: $Details"
    
    try {
        Add-Content -Path $ErrorDetailsFile -Value $LogEntry -Encoding UTF8 -ErrorAction Stop
    } catch { }
}

function Test-FileStability {
    param([string]$FilePath)
    
    try {
        $File = Get-Item -Path $FilePath -ErrorAction Stop
        
        try {
            $Stream = [System.IO.File]::Open($FilePath, 'Open', 'Read', 'None')
            $Stream.Close()
            return $true
        } catch {
            return $false
        }
    } catch {
        return $false
    }
}

function Wait-FileStability {
    param([string]$FilePath, [int]$TimeoutSeconds = 120)
    
    $Elapsed = 0
    
    while ($Elapsed -lt $TimeoutSeconds) {
        if (Test-FileStability -FilePath $FilePath) {
            return $true
        }
        Start-Sleep -Seconds 2
        $Elapsed += 2
    }
    
    return $false
}

function Get-ArchiveGroups {
    param([string]$Path)
    
    try {
        $Files = @(Get-ChildItem -Path $Path -File -ErrorAction SilentlyContinue | 
                   Where-Object { $_.Extension -match '\.(7z|zip)' -or $_.Name -match '\.(001|002|003|004|005|006|007|008|009)$' })
        
        if ($Files.Count -eq 0) { return @() }
        
        $Groups = @{}
        foreach ($File in $Files) {
            $BaseName = $File.Name -replace '\.\d{3}$', ''
            $BaseName = $BaseName -replace '\.zip$', ''
            $BaseName = $BaseName -replace '\.7z$', ''
            
            if (-not $Groups.ContainsKey($BaseName)) {
                $Groups[$BaseName] = @()
            }
            $Groups[$BaseName] += $File
        }
        
        return $Groups
    } catch {
        Write-Log "Error scanning archives: $_" -Type "Error"
        Write-ErrorDetailsLog "Get-ArchiveGroups" "N/A" "Scan Error" $_
        return @()
    }
}

function Get-ExpectedPartCount {
    param([string]$FilePath)
    
    try {
        if (-not (Wait-FileStability -FilePath $FilePath)) {
            Write-Log "First part file still being written: $(Split-Path $FilePath -Leaf)" -Type "Warning"
            return $null
        }
        
        $ListOutput = @(& $7zipPath l $FilePath 2>&1)
        
        foreach ($Line in $ListOutput) {
            if ($Line -match "Volumes\s*=\s*(\d+)") {
                $VolumeCount = [int]$matches[1]
                Write-Log "Archive has $VolumeCount volume(s)" -Type "Info"
                return $VolumeCount
            }
        }
        
        return $null
    } catch {
        Write-Log "Error querying archive volumes: $_" -Type "Error"
        $ArchiveName = Split-Path $FilePath -Leaf
        Write-ErrorDetailsLog "Get-ExpectedPartCount" $ArchiveName "Query Error" $_
        return $null
    }
}

function Verify-AllPartsPresentAndStable {
    param([string]$BaseName, [string]$SourcePath, [int]$ExpectedCount)
    
    $PartFiles = @(Get-ChildItem -Path $SourcePath -File -ErrorAction SilentlyContinue | 
                   Where-Object { $_.Name -like "$BaseName*" } | Sort-Object Name)
    
    $ActualCount = $PartFiles.Count
    
    Write-Log "Verifying parts for $BaseName : Expected=$ExpectedCount, Found=$ActualCount" -Type "Info"
    
    if ($ActualCount -lt $ExpectedCount) {
        $MissingCount = $ExpectedCount - $ActualCount
        $Message = "INCOMPLETE - Missing $MissingCount of $ExpectedCount parts. Found: $ActualCount parts"
        Write-Log $Message -Type "Warning"
        Write-MissingPartsLog $BaseName $Message
        
        $MissingFiles = @()
        for ($i = 1; $i -le $ExpectedCount; $i++) {
            $PartNum = $i.ToString("000")
            $PartName = "$BaseName.$PartNum"
            if (-not ($PartFiles | Where-Object { $_.Name -eq $PartName })) {
                $MissingFiles += $PartName
            }
        }
        
        if ($MissingFiles.Count -gt 0) {
            Write-Log "Missing files: $($MissingFiles -join ', ')" -Type "Warning"
            Write-MissingPartsLog $BaseName "Missing: $($MissingFiles -join ', ')"
        }
        
        return $false
    }
    
    Write-Log "All $ExpectedCount parts found. Verifying file stability..." -Type "Info"
    
    $UnstableFiles = @()
    foreach ($Part in $PartFiles) {
        if (-not (Wait-FileStability -FilePath $Part.FullName -TimeoutSeconds 30)) {
            $UnstableFiles += $Part.Name
        }
    }
    
    if ($UnstableFiles.Count -gt 0) {
        $Message = "Parts still being copied: $($UnstableFiles -join ', ')"
        Write-Log $Message -Type "Warning"
        Write-MissingPartsLog $BaseName $Message
        return $false
    }
    
    Write-Log "All $ExpectedCount parts present and stable for: $BaseName" -Type "Success"
    return $true
}

function Test-ArchiveIntegrity {
    param([string]$FilePath)
    
    $FileName = Split-Path $FilePath -Leaf
    Write-Log "Testing archive integrity: $FileName" -Type "Info"
    
    try {
        $TestOutput = @(& $7zipPath t $FilePath 2>&1)
        
        if ($LASTEXITCODE -eq 0) {
            Write-Log "Archive integrity test PASSED: $FileName" -Type "Success"
            return $true
        } else {
            Write-Log "Archive integrity test FAILED: $FileName" -Type "Error"
            $BaseName = $FileName -replace '\.\d{3}$', '' -replace '\.zip$', '' -replace '\.7z$', ''
            Write-FailedArchiveLog $BaseName "Integrity Test Failed" ($TestOutput | Out-String)
            $script:ErrorCount++
            return $false
        }
    } catch {
        Write-Log "Exception during integrity test: $_" -Type "Error"
        $BaseName = $FileName -replace '\.\d{3}$', '' -replace '\.zip$', '' -replace '\.7z$', ''
        Write-ErrorDetailsLog "Test-ArchiveIntegrity" $BaseName "Exception" $_
        $script:ErrorCount++
        return $false
    }
}

function Extract-Archive {
    param([string]$FirstPartPath, [string]$DestinationPath)
    
    try {
        $ArchiveName = Split-Path $FirstPartPath -Leaf
        $ArchiveName = $ArchiveName -replace '\.\d{3}$', ''
        $ArchiveName = $ArchiveName -replace '\.zip$', ''
        $ArchiveName = $ArchiveName -replace '\.7z$', ''
        
        $Timestamp = Get-Date -Format "yyyy-MM-dd_HH-mm-ss"
        $FolderName = "$ArchiveName`_$Timestamp"
        $FinalDestination = Join-Path -Path $DestinationPath -ChildPath $FolderName
        
        if (-not (Test-Path $FinalDestination)) {
            New-Item -ItemType Directory -Path $FinalDestination -Force | Out-Null
            Write-Log "Created extraction directory: $FinalDestination" -Type "Info"
        }
        
        Write-Log "Extracting archive to: $FinalDestination" -Type "Info"
        
        $ExtractOutput = @(& $7zipPath x $FirstPartPath "-o$FinalDestination" 2>&1)
        
        if ($LASTEXITCODE -eq 0) {
            Write-Log "Archive extraction completed successfully: $ArchiveName" -Type "Success"
            $script:SuccessCount++
            return $FinalDestination
        } else {
            Write-Log "Archive extraction FAILED: $ArchiveName" -Type "Error"
            Write-FailedArchiveLog $ArchiveName "Extraction Failed" ($ExtractOutput | Out-String)
            $script:ErrorCount++
            return $null
        }
    } catch {
        Write-Log "Exception during extraction: $_" -Type "Error"
        Write-ErrorDetailsLog "Extract-Archive" $ArchiveName "Exception" $_
        $script:ErrorCount++
        return $null
    }
}

function Move-ArchiveFiles {
    param([string]$BaseName, [string]$SourcePath, [string]$DestinationParent)
    
    try {
        $RawFolder = Join-Path -Path $DestinationParent -ChildPath "RAW"
        
        if (-not (Test-Path $RawFolder)) {
            New-Item -ItemType Directory -Path $RawFolder -Force | Out-Null
            Write-Log "Created RAW folder: $RawFolder" -Type "Info"
        }
        
        $ArchiveFiles = @(Get-ChildItem -Path $SourcePath -File -ErrorAction SilentlyContinue | 
                         Where-Object { $_.Name -like "$BaseName*" })
        
        if ($ArchiveFiles.Count -eq 0) {
            Write-Log "No archive files found to move: $BaseName" -Type "Warning"
            return
        }
        
        Write-Log "Moving $($ArchiveFiles.Count) archive files to RAW folder..." -Type "Info"
        
        foreach ($File in $ArchiveFiles) {
            try {
                if (Wait-FileStability -FilePath $File.FullName) {
                    $DestPath = Join-Path -Path $RawFolder -ChildPath $File.Name
                    Move-Item -Path $File.FullName -Destination $DestPath -Force -ErrorAction Stop
                    Write-Log "Moved to RAW: $($File.Name)" -Type "Success"
                } else {
                    Write-Log "File still in use, cannot move: $($File.Name)" -Type "Warning"
                }
            } catch {
                Write-Log "Failed to move $($File.Name): $_" -Type "Error"
                Write-ErrorDetailsLog "Move-ArchiveFiles" $BaseName "Move Failed" $_
                $script:ErrorCount++
            }
        }
    } catch {
        Write-Log "Exception in Move-ArchiveFiles: $_" -Type "Error"
        Write-ErrorDetailsLog "Move-ArchiveFiles" $BaseName "Exception" $_
    }
}

function Show-Countdown {
    param([int]$Seconds)
    
    for ($i = $Seconds; $i -gt 0; $i--) {
        Write-Host "`rNext cycle in $i seconds..." -ForegroundColor Cyan -NoNewline
        Start-Sleep -Seconds 1
    }
    Write-Host ""
}

function Main {
    Write-Log "=== 7-Zip Multi-Split Archive Extractor Started ===" -Type "Info"
    Write-Log "Base path: $BasePath | Inbound: $InboundPath | Extracted: $ExtractedPath" -Type "Info"
    Write-Log "Logs: $LogFolder" -Type "Info"
    Write-Log "Check interval: $CheckIntervalSeconds seconds | Auto-restart after $EmptyCyclesBeforeRestart empty cycles" -Type "Info"
    
    foreach ($Dir in @($InboundPath, $ExtractedPath, $LogFolder)) {
        try {
            if (-not (Test-Path $Dir)) {
                New-Item -ItemType Directory -Path $Dir -Force | Out-Null
                Write-Log "Created directory: $Dir" -Type "Info"
            }
        } catch {
            Write-Log "Failed to create $Dir : $_" -Type "Error"
            Write-ErrorDetailsLog "Main" "N/A" "Directory Creation" $_
        }
    }
    
    $CycleCount = 0
    
    while ($true) {
        try {
            $CycleCount++
            Write-Log "--- Scan Cycle #$CycleCount (Empty cycles: $script:ConsecutiveEmptyCycles/$EmptyCyclesBeforeRestart) ---" -Type "Info"
            
            $ArchiveGroups = Get-ArchiveGroups -Path $InboundPath
            
            if ($ArchiveGroups.Count -eq 0) {
                Write-Log "No archives found in inbound folder." -Type "Warning"
                $script:ConsecutiveEmptyCycles++
                Write-Log "Empty cycle count incremented to: $script:ConsecutiveEmptyCycles / $EmptyCyclesBeforeRestart" -Type "Warning"
                
                if ($script:ConsecutiveEmptyCycles -ge $EmptyCyclesBeforeRestart) {
                    Write-Log "========== FORCE RESTART TRIGGERED ==========" -Type "Error"
                    Write-Log "Reached $script:ConsecutiveEmptyCycles empty cycles. Restarting process..." -Type "Error"
                    Start-Sleep -Seconds 3
                    Write-Log "Executing restart..." -Type "Error"
                    Start-Sleep -Seconds 2
                    
                    # Force restart - spawn new process and exit current
                    $ScriptPath = $PSCommandPath
                    $params = "-NoProfile -ExecutionPolicy Bypass -File `"$ScriptPath`""
                    Start-Process powershell -ArgumentList $params -WindowStyle Normal
                    
                    Write-Log "Restart process spawned. Exiting current instance..." -Type "Error"
                    exit 0
                }
                
                Show-Countdown $CheckIntervalSeconds
                continue
            }
            
            $script:ConsecutiveEmptyCycles = 0
            
            Write-Log "Found $($ArchiveGroups.Count) archive group(s)" -Type "Success"
            $ProcessedThisCycle = 0
            
            foreach ($BaseName in $ArchiveGroups.Keys) {
                try {
                    if ($ProcessedArchives.ContainsKey($BaseName) -and $ProcessedArchives[$BaseName] -eq "completed") {
                        Write-Log "Archive already processed: $BaseName (skipping)" -Type "Info"
                        continue
                    }
                    
                    if ($ProcessedArchives.ContainsKey($BaseName) -and $ProcessedArchives[$BaseName] -eq "failed_integrity") {
                        Write-Log "Archive previously failed integrity: $BaseName (skipping)" -Type "Warning"
                        continue
                    }
                    
                    $PartFiles = $ArchiveGroups[$BaseName]
                    $FirstPart = $PartFiles | Sort-Object Name | Select-Object -First 1
                    
                    Write-Log "Processing: $BaseName ($($PartFiles.Count) parts found)" -Type "Info"
                    
                    $ExpectedCount = Get-ExpectedPartCount -FilePath $FirstPart.FullName
                    
                    if ($null -eq $ExpectedCount) {
                        $ExpectedCount = 1
                        Write-Log "Single-part archive detected: $BaseName" -Type "Info"
                    }
                    
                    $AllPartsPresentAndStable = Verify-AllPartsPresentAndStable -BaseName $BaseName -SourcePath $InboundPath -ExpectedCount $ExpectedCount
                    
                    if (-not $AllPartsPresentAndStable) {
                        Write-Log "Cannot process yet - waiting for missing or unstable parts" -Type "Warning"
                        if (-not $ProcessedArchives.ContainsKey($BaseName)) {
                            $ProcessedArchives[$BaseName] = "waiting"
                        }
                        continue
                    }
                    
                    Write-Log "All parts verified. Starting integrity test..." -Type "Info"
                    $IntegrityOK = Test-ArchiveIntegrity -FilePath $FirstPart.FullName
                    
                    if (-not $IntegrityOK) {
                        Write-Log "Archive failed integrity test: $BaseName - SKIPPING" -Type "Error"
                        $ProcessedArchives[$BaseName] = "failed_integrity"
                        continue
                    }
                    
                    $ArchiveExtractPath = Join-Path -Path $ExtractedPath -ChildPath $BaseName
                    
                    if (-not (Test-Path $ArchiveExtractPath)) {
                        New-Item -ItemType Directory -Path $ArchiveExtractPath -Force | Out-Null
                    }
                    
                    Write-Log "Starting extraction process..." -Type "Info"
                    $ExtractionResult = Extract-Archive -FirstPartPath $FirstPart.FullName -DestinationPath $ArchiveExtractPath
                    
                    if ($ExtractionResult) {
                        Write-Log "Extraction successful. Moving archive files to RAW folder..." -Type "Success"
                        Move-ArchiveFiles -BaseName $BaseName -SourcePath $InboundPath -DestinationParent $ArchiveExtractPath
                        $ProcessedArchives[$BaseName] = "completed"
                        $ProcessedThisCycle++
                        Write-Log "=== Successfully completed: $BaseName ===" -Type "Success"
                    } else {
                        $ProcessedArchives[$BaseName] = "extraction_failed"
                        Write-Log "Extraction failed for: $BaseName" -Type "Error"
                    }
                } catch {
                    Write-Log "Exception processing $BaseName : $_" -Type "Error"
                    Write-ErrorDetailsLog "Archive Processing" $BaseName "Unhandled Exception" $_
                    $ProcessedArchives[$BaseName] = "error"
                }
            }
            
            $WaitingCount = ($ProcessedArchives.Values | Where-Object { $_ -eq "waiting" }).Count
            $FailedCount = ($ProcessedArchives.Values | Where-Object { $_ -in "failed_integrity", "error", "extraction_failed" }).Count
            $CompletedCount = ($ProcessedArchives.Values | Where-Object { $_ -eq "completed" }).Count
            
            Write-Log "CYCLE SUMMARY - Processed This Cycle: $ProcessedThisCycle | Total Completed: $CompletedCount | Waiting: $WaitingCount | Failed: $FailedCount | Total Errors: $ErrorCount" -Type "Info"
            
            # Auto-restart condition: when waiting=0 AND (failed>=1 OR total errors>=1)
            if ($WaitingCount -eq 0 -and ($FailedCount -ge 1 -or $ErrorCount -ge 1)) {
                Write-Log "AUTO-RESTART TRIGGERED: Waiting=$WaitingCount, Failed=$FailedCount, Errors=$ErrorCount" -Type "Warning"
                Write-Log "RESTARTING SCRIPT for recovery..." -Type "Warning"
                Start-Sleep -Seconds 5
                & $PSCommandPath
                exit 0
            }
            
            Show-Countdown $CheckIntervalSeconds
            
        } catch {
            Write-Log "CRITICAL EXCEPTION in main loop: $_" -Type "Error"
            Write-ErrorDetailsLog "Main Loop" "N/A" "Critical Exception" $_
            $script:ErrorCount++
            $host.UI.RawUI.BackgroundColor = "Red"
            Write-Host "ERROR DETECTED - Continuing in 10 seconds..." -ForegroundColor White -BackgroundColor Red
            Start-Sleep -Seconds 10
            $host.UI.RawUI.BackgroundColor = "Black"
            Clear-Host
        }
    }
}

try {
    Main
} catch {
    Write-Log "FATAL ERROR: $_" -Type "Error"
    Write-ErrorDetailsLog "Script Exit" "N/A" "Fatal Error" $_
    $host.UI.RawUI.BackgroundColor = "Red"
    Clear-Host
    Write-Host "FATAL ERROR - Script terminated. Check log: $LogFile" -ForegroundColor White -BackgroundColor Red
    exit 1
}