# 7-Zip Multi-Split Archive Extractor Script
# Bulletproof version with detailed logging, countdown, and auto-restart

param(
    [string]$BasePath = "d:\unzipper",
    [string]$InboundPath = "d:\unzipper\inbound",
    [string]$ExtractedPath = "d:\unzipper\extracted",
    [int]$CheckIntervalSeconds = 10,
    [int]$EmptyCyclesBeforeRestart = 10
)

$7zipPath = "C:\Program Files\7-Zip\7z.exe"
$LogFolder = Join-Path -Path $BasePath -ChildPath "logs"
$MissingPartsFile = Join-Path -Path $LogFolder -ChildPath "missing_parts_log.txt"
$FailedArchivesFile = Join-Path -Path $LogFolder -ChildPath "failed_archives_log.txt"
$ErrorDetailsFile = Join-Path -Path $LogFolder -ChildPath "error_details_log.txt"
$ErrorCount = 0
$SuccessCount = 0
$ProcessedArchives = @{}
$ConsecutiveEmptyCycles = 0

if (-not (Test-Path $LogFolder)) {
    New-Item -ItemType Directory -Path $LogFolder -Force | Out-Null
}

$LogFile = Join-Path -Path $LogFolder -ChildPath "extraction_log_$(Get-Date -Format 'yyyyMMdd_HHmmss').txt"

if (-not (Test-Path $7zipPath)) {
    Write-Host "ERROR: 7-Zip not found at $7zipPath" -ForegroundColor Red
    exit 1
}

$host.UI.RawUI.BackgroundColor = "Black"
Clear-Host

function Write-Log {
    param([string]$Message, [ValidateSet("Info", "Success", "Warning", "Error")][string]$Type = "Info")
    
    $Timestamp = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
    $LogEntry = "[$Timestamp] [$Type] $Message"
    
    try {
        Add-Content -Path $LogFile -Value $LogEntry -Encoding UTF8 -ErrorAction Stop
    } catch { }
    
    $Color = switch ($Type) {
        "Success" { "Green" }
        "Warning" { "Yellow" }
        "Error" { "Red" }
        default { "Cyan" }
    }
    
    Write-Host $LogEntry -ForegroundColor $Color
}

function Write-MissingPartsLog {
    param([string]$ArchiveName, [string]$Message)
    
    $Timestamp = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
    $LogEntry = "[$Timestamp] $ArchiveName : $Message"
    
    try {
        Add-Content -Path $MissingPartsFile -Value $LogEntry -Encoding UTF8 -ErrorAction Stop
    } catch { }
}

function Write-FailedArchiveLog {
    param([string]$ArchiveName, [string]$Reason, [string]$Details)
    
    $Timestamp = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
    $LogEntry = "[$Timestamp] ARCHIVE: $ArchiveName | REASON: $Reason"
    
    try {
        Add-Content -Path $FailedArchivesFile -Value $LogEntry -Encoding UTF8 -ErrorAction Stop
        if ($Details) {
            Add-Content -Path $FailedArchivesFile -Value "    DETAILS: $Details" -Encoding UTF8 -ErrorAction Stop
        }
        Add-Content -Path $FailedArchivesFile -Value "" -Encoding UTF8 -ErrorAction Stop
    } catch { }
}

function Write-ErrorDetailsLog {
    param([string]$Component, [string]$ArchiveName, [string]$Error, [string]$Details)
    
    $Timestamp = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
    $LogEntry = "[$Timestamp] COMPONENT: $Component | ARCHIVE: $ArchiveName | ERROR: $Error | DETAILS: $Details"
    
    try {
        Add-Content -Path $ErrorDetailsFile -Value $LogEntry -Encoding UTF8 -ErrorAction Stop
    } catch { }
}

function Show-YodaArt {
    $YodaArt = @"
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣀⣤⣤⠤⠐⠂⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⡌⡦⠊⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⡀⣼⡊⢀⠔⠀⠀⣄⠤⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣀⣤⣤⣄⣀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢠⣶⠃⠉⠡⡠⠤⠊⠀⠠⣀⣀⡠⠔⠒⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣠⣾⣿⢟⠿⠛⠛⠁
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣼⡇⠀⠀⠀⠀⠑⠶⠖⠊⠁⠀⠀⠀⡀⠀⠀⠀⢀⣠⣤⣤⡀⠀⠀⠀⠀⠀⢀⣠⣤⣶⣿⣿⠟⡱⠁⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢰⣾⣿⡇⠀⢀⡠⠀⠀⠀⠈⠑⢦⣄⣀⣀⣽⣦⣤⣾⣿⠿⠿⠿⣿⡆⠀⠀⢀⠺⣿⣿⣿⣿⡿⠁⡰⠁⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣾⣿⣿⣧⣠⠊⣠⣶⣾⣿⣿⣶⣶⣿⣿⠿⠛⢿⣿⣫⢕⡠⢥⣈⠀⠙⠀⠰⣷⣿⣿⣿⡿⠋⢀⠜⠁⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠠⢿⣿⣿⣿⣿⣰⣿⣿⠿⣛⡛⢛⣿⣿⣟⢅⠀⠀⢿⣿⠕⢺⣿⡇⠩⠓⠂⢀⠛⠛⠋⢁⣠⠞⠁⠀⠀⠀⠀⠀⠀⠀⠀
⠘⢶⡶⢶⣶⣦⣤⣤⣤⣤⣤⣀⣀⣀⣀⡀⠀⠘⣿⣿⣿⠟⠁⡡⣒⣬⢭⢠⠝⢿⡡⠂⠀⠈⠻⣯⣖⣒⣺⡭⠂⢀⠈⣶⣶⣾⠟⠁⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠙⠳⣌⡛⢿⣿⣿⣿⣿⣿⣿⣿⣻⣵⣨⣿⣿⡏⢀⠪⠎⠙⠿⣋⠴⡃⢸⣷⣤⣶⡾⠋⠈⠻⣶⣶⣶⣶⣷⣶⣷⣿⣟⠁⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠈⠛⢦⣌⡙⠛⠿⣿⣿⣿⣿⣿⣿⣿⣿⡀⠀⠀⠩⠭⡭⠴⠊⢀⠀⠀⠀⠀⠀⠀⠀⠀⠈⣿⣿⣿⣿⣿⡇⠁⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠈⠙⠓⠦⣄⡉⠛⠛⠻⢿⣿⣿⣷⡀⠀⠀⠀⠀⢀⣰⠋⠀⠀⠀⠀⠀⣀⣰⠤⣳⣿⣿⣿⣿⣟⠑⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠉⠓⠒⠒⠶⢺⣿⣿⣿⣦⣄⣀⣴⣿⣯⣤⣔⠒⠚⣒⣉⣉⣴⣾⣿⣿⣿⣿⣿⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠛⠹⢿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡇⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠙⣿⣿⣿⣿⣿⣿⣿⣿⣿⣭⣉⣉⣤⣿⣿⣿⣿⣿⣿⡿⢀⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣠⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡿⠟⡁⡆⠙⢶⣀⠀⢀⣀⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⣀⣴⣶⣾⣿⣟⢿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⠿⢛⣩⣴⣿⠇⡇⠸⡆⠙⢷⣄⠻⣿⣦⡄⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⣼⣿⣿⣿⣿⣿⣿⣿⣎⢻⣿⣿⣿⣿⣿⣿⣭⣭⣭⣵⣶⣾⣿⣿⣿⣿⠟⢰⢣⠀⠈⠀⠀⠙⢷⡎⠙⣿⣦⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⣼⣿⣿⣿⣿⣿⣿⣿⡟⣿⡆⢻⣿⣿⣿⣿⣿⣿⣿⣿⣿⠿⠿⠟⠛⠋⠁⢀⠇⢸⡇⠀⠀⠀⠀⠀⠈⠁⠀⢸⣿⡆⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢠⣾⣿⣿⣿⣿⣿⣿⣿⣿⣿⡜⡿⡘⣿⣿⣿⣿⣿⣶⣶⣤⣤⣤⣤⣤⣤⣤⣴⡎⠖⢹⡇⠀⠀⠀⠀⠀⠀⠀⠀⠀⣿⣷⡄⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣦⡀⠘⢿⣿⣿⣿⣿⣿⣿⣿⣿⠿⠿⠛⠋⡟⠀⠀⣸⣷⣀⣤⣀⣀⣀⣤⣤⣾⣿⣿⣿⣿⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⣸⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣭⣓⡲⠬⢭⣙⡛⠿⣿⣿⣶⣦⣀⠀⡜⠀⠀⣰⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡇⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⢀⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣭⣛⣓⠶⠦⠥⣀⠙⠋⠉⠉⠻⣄⣀⣸⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡇⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⣼⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣷⣶⣆⠐⣦⣠⣷⠊⠁⠀⠀⡭⠙⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡆⠀⠀
⠀⠀⠀⠀⠀⠀⠀⢠⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡿⢉⣛⡛⢻⡗⠂⠀⢀⣷⣄⠈⢆⠉⠙⠻⢿⣿⣿⣿⣿⣿⣿⠇⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠘⣿⣿⡟⢻⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡟⣉⢁⣴⣿⣿⣾⡇⢀⣀⣼⡿⣿⣷⡌⢻⣦⡀⠀⠈⠙⠛⠿⠏⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠙⢿⣿⡄⠙⢿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⠿⠛⠛⠛⢯⡉⠉⠉⠉⠛⢼⣿⠿⠿⠦⡙⣿⡆⢹⣷⣤⡀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠘⠿⠄⠈⠻⠿⠿⠿⠿⠿⠿⠛⠛⠿⠛⠉⠁⠀⠀⠀⠀⠀⠀⠻⠿⠿⠿⠿⠟⠉⠀⠀⠤⠴⠶⠌⠿⠘⠿⠿⠿⠿⠶⠤⠀⠀⠀⠀
"@
    
    Write-Host $YodaArt -ForegroundColor Green
}

function Test-FileStability {
    param([string]$FilePath)
    
    try {
        $File = Get-Item -Path $FilePath -ErrorAction Stop
        
        try {
            $Stream = [System.IO.File]::Open($FilePath, 'Open', 'Read', 'None')
            $Stream.Close()
            return $true
        } catch {
            return $false
        }
    } catch {
        return $false
    }
}

function Wait-FileStability {
    param([string]$FilePath, [int]$TimeoutSeconds = 120)
    
    $Elapsed = 0
    
    while ($Elapsed -lt $TimeoutSeconds) {
        if (Test-FileStability -FilePath $FilePath) {
            return $true
        }
        Start-Sleep -Seconds 2
        $Elapsed += 2
    }
    
    return $false
}

function Get-ArchiveGroups {
    param([string]$Path)
    
    try {
        $Files = @(Get-ChildItem -Path $Path -File -ErrorAction SilentlyContinue | 
                   Where-Object { $_.Extension -match '\.(7z|zip)' -or $_.Name -match '\.(001|002|003|004|005|006|007|008|009)$' })
        
        if ($Files.Count -eq 0) { return @() }
        
        $Groups = @{}
        foreach ($File in $Files) {
            $BaseName = $File.Name -replace '\.\d{3}$', ''
            $BaseName = $BaseName -replace '\.zip$', ''
            $BaseName = $BaseName -replace '\.7z$', ''
            
            if (-not $Groups.ContainsKey($BaseName)) {
                $Groups[$BaseName] = @()
            }
            $Groups[$BaseName] += $File
        }
        
        return $Groups
    } catch {
        Write-Log "Error scanning archives: $_" -Type "Error"
        Write-ErrorDetailsLog "Get-ArchiveGroups" "N/A" "Scan Error" $_
        return @()
    }
}

function Get-ExpectedPartCount {
    param([string]$FilePath)
    
    try {
        if (-not (Wait-FileStability -FilePath $FilePath)) {
            Write-Log "First part file still being written: $(Split-Path $FilePath -Leaf)" -Type "Warning"
            return $null
        }
        
        $ListOutput = @(& $7zipPath l $FilePath 2>&1)
        
        foreach ($Line in $ListOutput) {
            if ($Line -match "Volumes\s*=\s*(\d+)") {
                $VolumeCount = [int]$matches[1]
                Write-Log "Archive has $VolumeCount volume(s)" -Type "Info"
                return $VolumeCount
            }
        }
        
        return $null
    } catch {
        Write-Log "Error querying archive volumes: $_" -Type "Error"
        $ArchiveName = Split-Path $FilePath -Leaf
        Write-ErrorDetailsLog "Get-ExpectedPartCount" $ArchiveName "Query Error" $_
        return $null
    }
}

function Verify-AllPartsPresentAndStable {
    param([string]$BaseName, [string]$SourcePath, [int]$ExpectedCount)
    
    $PartFiles = @(Get-ChildItem -Path $SourcePath -File -ErrorAction SilentlyContinue | 
                   Where-Object { $_.Name -like "$BaseName*" } | Sort-Object Name)
    
    $ActualCount = $PartFiles.Count
    
    Write-Log "Verifying parts for $BaseName : Expected=$ExpectedCount, Found=$ActualCount" -Type "Info"
    
    if ($ActualCount -lt $ExpectedCount) {
        $MissingCount = $ExpectedCount - $ActualCount
        $Message = "INCOMPLETE - Missing $MissingCount of $ExpectedCount parts. Found: $ActualCount parts"
        Write-Log $Message -Type "Warning"
        Write-MissingPartsLog $BaseName $Message
        
        $MissingFiles = @()
        for ($i = 1; $i -le $ExpectedCount; $i++) {
            $PartNum = $i.ToString("000")
            $PartName = "$BaseName.$PartNum"
            if (-not ($PartFiles | Where-Object { $_.Name -eq $PartName })) {
                $MissingFiles += $PartName
            }
        }
        
        if ($MissingFiles.Count -gt 0) {
            Write-Log "Missing files: $($MissingFiles -join ', ')" -Type "Warning"
            Write-MissingPartsLog $BaseName "Missing: $($MissingFiles -join ', ')"
        }
        
        return $false
    }
    
    Write-Log "All $ExpectedCount parts found. Verifying file stability..." -Type "Info"
    
    $UnstableFiles = @()
    foreach ($Part in $PartFiles) {
        if (-not (Wait-FileStability -FilePath $Part.FullName -TimeoutSeconds 30)) {
            $UnstableFiles += $Part.Name
        }
    }
    
    if ($UnstableFiles.Count -gt 0) {
        $Message = "Parts still being copied: $($UnstableFiles -join ', ')"
        Write-Log $Message -Type "Warning"
        Write-MissingPartsLog $BaseName $Message
        return $false
    }
    
    Write-Log "All $ExpectedCount parts present and stable for: $BaseName" -Type "Success"
    return $true
}

function Test-ArchiveIntegrity {
    param([string]$FilePath)
    
    $FileName = Split-Path $FilePath -Leaf
    Write-Log "Testing archive integrity: $FileName" -Type "Info"
    
    try {
        $TestOutput = @(& $7zipPath t $FilePath 2>&1)
        
        if ($LASTEXITCODE -eq 0) {
            Write-Log "Archive integrity test PASSED: $FileName" -Type "Success"
            return $true
        } else {
            Write-Log "Archive integrity test FAILED: $FileName" -Type "Error"
            $BaseName = $FileName -replace '\.\d{3}$', '' -replace '\.zip$', '' -replace '\.7z$', ''
            Write-FailedArchiveLog $BaseName "Integrity Test Failed" ($TestOutput | Out-String)
            $script:ErrorCount++
            return $false
        }
    } catch {
        Write-Log "Exception during integrity test: $_" -Type "Error"
        $BaseName = $FileName -replace '\.\d{3}$', '' -replace '\.zip$', '' -replace '\.7z$', ''
        Write-ErrorDetailsLog "Test-ArchiveIntegrity" $BaseName "Exception" $_
        $script:ErrorCount++
        return $false
    }
}

function Extract-Archive {
    param([string]$FirstPartPath, [string]$DestinationPath)
    
    try {
        $ArchiveName = Split-Path $FirstPartPath -Leaf
        $ArchiveName = $ArchiveName -replace '\.\d{3}$', ''
        $ArchiveName = $ArchiveName -replace '\.zip$', ''
        $ArchiveName = $ArchiveName -replace '\.7z$', ''
        
        $Timestamp = Get-Date -Format "yyyy-MM-dd_HH-mm-ss"
        $FolderName = "$ArchiveName`_$Timestamp"
        $FinalDestination = Join
