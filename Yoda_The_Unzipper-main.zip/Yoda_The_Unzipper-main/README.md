Below is a clear, structured explanation of what this PowerShell script does, at both a high level and a detailed operational level, plus a few important behavioral notes so you know exactly how it will behave in production.


---

🔎 High-level purpose

This script is a robust, self-healing watch-folder extractor for single or multi-part 7-Zip / ZIP archives.

It continuously:

Watches an inbound folder

Detects split archives (.7z.001, .zip.001, etc.)

Waits until all parts are present and no longer being written

Verifies archive integrity

Extracts safely

Moves original archive parts into a RAW folder

Logs everything

Automatically restarts itself when errors or prolonged idle conditions occur


This is designed for unattended / long-running use (servers, NAS drop folders, automated transfers).


---

📁 Folder structure it uses

d:\unzipper
├── inbound        ← files arrive here
├── extracted      ← extracted content goes here
│   └── ArchiveName
│       ├── ArchiveName_YYYY-MM-DD_HH-MM-SS
│       └── RAW     ← original archive parts moved here
└── logs
    ├── extraction_log_*.txt
    ├── missing_parts_log.txt
    ├── failed_archives_log.txt
    └── error_details_log.txt


---

⚙️ What the script does step-by-step

1️⃣ Startup & validation

Validates 7-Zip exists

Creates required directories

Initializes log files

Sets console background to black

Starts an infinite processing loop



---

2️⃣ Scan cycle (every CheckIntervalSeconds)

Each cycle:

Scans InboundPath for:

.7z, .zip

split files .001, .002, .003, etc.


Groups files by base archive name


Example:

movie.7z.001
movie.7z.002
movie.7z.003

→ grouped as movie


---

3️⃣ Detects archive structure

For each archive group:

Uses 7z l to determine:

Expected number of volumes


If volume count cannot be determined → assumes single-part archive



---

4️⃣ Waits for completeness & stability

Before touching an archive it ensures:

✅ All parts exist
✅ No parts are still being written to
✅ No file locks

If anything is missing or unstable:

Logs to missing_parts_log.txt

Marks archive as waiting

Skips until next scan



---

5️⃣ Integrity testing (CRITICAL SAFETY STEP)

Once all parts are present:

Runs:

7z t archive.7z.001

If integrity fails:

Logs failure

Marks archive as failed_integrity

Will never retry that archive




---

6️⃣ Extraction

If integrity passes:

Creates a timestamped extraction folder

Extracts using:

7z x archive.7z.001

On success:

Increments success counter


On failure:

Logs full error output

Marks archive as failed




---

7️⃣ Post-processing (RAW archive handling)

After successful extraction:

Creates:

extracted\ArchiveName\RAW

Moves all original archive parts into RAW

Prevents re-processing forever



---

🔄 Intelligent restart logic (self-healing)

🔁 Restart if idle too long

If no archives are found for:

EmptyCyclesBeforeRestart (default: 10)

Then the script:

Spawns a fresh PowerShell process

Exits the current one


✅ Prevents memory leaks
✅ Clears stuck file handles
✅ Keeps system healthy long-term


---

🔁 Restart after errors

If:

No archives are waiting AND

Any failures or errors occurred


Then:

Script automatically restarts itself



---

🧠 State tracking (important)

The script remembers archive states during runtime:

State	Meaning

waiting	Missing or unstable parts
completed	Fully extracted & moved
failed_integrity	Integrity test failed (never retried)
extraction_failed	Extraction error
error	Unexpected exception


This prevents:

Re-extracting the same archive

Infinite retry loops

Reprocessing broken uploads



---

🧾 Logging system (very thorough)

Log file	Purpose

extraction_log_*.txt	Everything (main log)
missing_parts_log.txt	Missing or unstable volumes
failed_archives_log.txt	Integrity & extraction failures
error_details_log.txt	Stack-level diagnostic errors



---

🛡️ Safety & reliability features

✔ File-lock detection
✔ Wait-until-stable logic
✔ Integrity verification before extraction
✔ No duplicate processing
✔ Automatic recovery
✔ Timestamped extraction folders
✔ Graceful handling of partial uploads


---

✅ Bottom line

This script is production-grade and suitable for:

Automated ingest pipelines

NAS / FTP drop folders

Long-running archive processors

Environments where uploads arrive slowly or in parts

Situations where manual babysitting is unacceptable
